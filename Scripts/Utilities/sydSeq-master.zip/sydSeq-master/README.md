sydSeq
======

R package - sydSeq - various functions for gene expression analysis
